import java.util.Scanner;
public class day1 {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int n=sc.nextInt();
		int o=sc.nextInt();
		if(n>o) {
			System.out.println("n is greater");
			}
		else if(n<o) {
			System.out.println("o is greater");
			
		}
	}

}
