public class day1 {
	public static void main(String[] args) {
		for(int i=100;i>=0;i--) {
			System.out.print(i);
			System.out.print(" ");
			
		}
	}

}
